#' A Hello World Function
#'
#' This function outputs 'Hello World.' That is all.
#' @export
#' @examples
#' print_hello_world()

print_hello_world <- function(){
  print("Hello World.")
}